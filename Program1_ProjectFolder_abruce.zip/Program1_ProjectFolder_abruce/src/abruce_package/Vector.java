package abruce_package;

public class Vector {
	private double[][] vec;

	public Vector() {
		vec = new double[2][1];
		vec[0][0] = 0.0;
		vec[1][0] = 0.0;
	}

	public Vector(double component_1, double component_2) {
		vec = new double[2][1];
		vec[0][0] = component_1;
		vec[1][0] = component_2;
	}

	//Functionality:
	
	public double dot_product(Vector vector) {
		return (vec[0][0] * vector.get_component_1()) + (vec[1][0] * vector.get_component_2());
	}//end dot_product(Vector)

	public double dot_product(double[][] vector) {
		if(vector.length != 2 || vector[0].length != 1) {
			System.out.println("Invalid vector dimensions: " + vector.length);
			return 0.0;
		}else {
			return (vec[0][0] * vector[0][0]) + (vec[1][0] * vector[1][0]);
		}//end else block
	}//end dot_product(double[])


	//Getters and setters:
	public void set_vec(double component_1, double component_2) {
		vec = new double[2][1];
		vec[0][0] = component_1;
		vec[1][0] = component_2;
	}//end set_vec (double, double) method

	public void set_vec(Vector vector){
		vec = new double[2][1];
		vec[0][0] = vector.get_component_1();
		vec[1][0] = vector.get_component_2();
	}//end set_vec (Vector) method

	public void set_component_1(double component_1) {
		vec[0][0] = component_1;
	}

	public void set_component_2(double component_2) {
		vec[1][0] = component_2;
	}

	public double[][] get_vec(){
		return vec;
	}

	public double get_component_1() {
		return vec[0][0];
	}

	public double get_component_2() {
		return vec[1][0];
	}
}//end Vector class
