/**
 * 
 */
package abruce_package;
import java.io.File;
/**
 * 
 */
public class Main {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test_all();
		
	}

	public static void test_all() {
		//Create the objects and use the files created in part 1 to 
		System.out.println("\n\n=============================== Part 1 ===============================");
		abruce_p1 p1_obj = new abruce_p1();
		p1_obj.logic();
		File file_1 = p1_obj.share_file("abruce_mat1.txt");
		File file_2 = p1_obj.share_file("abruce_mat2.txt");
		File file_3 = p1_obj.share_file("abruce_mat3.txt");
		File file_4 = p1_obj.share_file("abruce_mat4.txt");
		
		
		System.out.println("\n\n=============================== Part 2 ===============================");
		abruce_p2 p2_obj = new abruce_p2(file_1, file_2, file_3, file_4);
		p2_obj.logic();
		
		
		System.out.println("\n\n=============================== Part 3 ===============================");	
		abruce_p3 p3_obj = new abruce_p3(file_1, file_2, file_3, file_4);
		p3_obj.logic();
		
		
		System.out.println("\n\n=============================== Part 4 ===============================");
		abruce_p4 p4_obj = new abruce_p4(file_1, file_2, file_3, file_4);
		p4_obj.logic();
		
		
		System.out.println("\n\n=============================== Part 5 ===============================");
		abruce_p5 p5_obj = new abruce_p5();
		p5_obj.logic();
		
		
		System.out.println("\n\n=============================== Part 6 ===============================");
		abruce_p6 p6_obj = new abruce_p6(file_1, file_2, file_3, file_4);
		p6_obj.logic();
		
		
		System.out.println("\n\n=============================== Part 7 ===============================");
		abruce_p7 p7_obj = new abruce_p7(file_1, file_2, file_3, file_4);
		p7_obj.logic();
		
		System.out.println("\n\n\n"
				+ "======================================================================"
				+ "\nAll processes finished successfully.");
	}//end test_all method
	
}//end Main class
