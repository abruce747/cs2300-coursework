package abruce_package;

import java.util.ArrayList;
import java.util.Scanner;
import Jama.Matrix;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class abruce_p4 {

	private ArrayList<ArrayList<Number>> mat_1;
	private ArrayList<ArrayList<Number>> mat_2;
	private ArrayList<ArrayList<Number>> mat_3;
	private ArrayList<ArrayList<Number>> mat_4;

	//Instance variables using my chosen library from https://math.nist.gov/javanumerics/jama/doc/Jama/package-summary.html
	private Matrix jama_mat_1;
	private Matrix jama_mat_2;
	private Matrix jama_mat_3;
	private Matrix jama_mat_4;

	public abruce_p4(File f1, File f2, File f3, File f4) {
		//Load the matrices
		mat_1 = read_file(f1);
		mat_2 = read_file(f2);
		mat_3 = read_file(f3);
		mat_4 = read_file(f4);

		load_jama_mat_1();
		load_jama_mat_2();
		load_jama_mat_3();
		load_jama_mat_4();
	}//end constructor

	public void logic() {
		//Use NIST jar file to do the adding and multiplying from parts 2 and 3.
		//Save them to their own files of format abruce_p4_outA12 for adding mat 1 and mat 2.
		//abruce_p4_outM13 for multiplying matrices 1 and 3

		//Matrix addition step
		jama_adding_logic();
		//Matrix multiplication step
		jama_multiplying_logic();
	}//end logic method


	//Handle the replication of part 2, but without user input
	public void jama_adding_logic() {
		//Code should check all possible combinations and write to a file:
		//mat_1 + mat_1, mat_1 + mat_2, 
		//mat_2 + mat_2,
		//mat_3 + mat_3, 
		//mat_4 + mat_4

		//mat_1 + mat_1:
		Matrix jama_mat_11 = jama_mat_1.plus(jama_mat_1);
		File jama_file_11 = create_output_file("Mat1", "Mat1", "p4", 'A');
		print_file(jama_mat_11, jama_file_11);

		//mat_1 + mat_2:
		Matrix jama_mat_12 = jama_mat_1.plus(jama_mat_2);
		File jama_file_12 = create_output_file("Mat1", "Mat2", "p4", 'A');
		print_file(jama_mat_12, jama_file_12);

		//mat_2 + mat_2:
		Matrix jama_mat_22 = jama_mat_2.plus(jama_mat_2);
		File jama_file_22 = create_output_file("Mat2", "Mat2", "p4", 'A');
		print_file(jama_mat_22, jama_file_22);

		//mat_3 + mat_3:
		Matrix jama_mat_33 = jama_mat_3.plus(jama_mat_3);
		File jama_file_33 = create_output_file("Mat3", "Mat3", "p4", 'A');
		print_file(jama_mat_33, jama_file_33);

		//mat_4 + mat_4:
		Matrix jama_mat_44 = jama_mat_4.plus(jama_mat_4);
		File jama_file_44 = create_output_file("Mat4", "Mat4", "p4", 'A');
		print_file(jama_mat_44, jama_file_44);
	}//end jama_adding_flow method

	public void jama_multiplying_logic() {
		//Code should check all possible combinations with the JAMA jar file
		//Only matrices that can be multiplied in pairs are:
		//mat_1 * mat_4
		//mat_2 * mat_4
		//mat_3 * mat_4
		//mat_4 * mat_3

		//mat_1 * mat_4
		Matrix jama_mat_14 = jama_mat_1.times(jama_mat_4);
		File jama_file_14 = create_output_file("Mat1", "Mat4", "p4", 'M');
		print_file(jama_mat_14, jama_file_14);

		//mat_2 * mat_4
		Matrix jama_mat_24 = jama_mat_2.times(jama_mat_4);
		File jama_file_24 = create_output_file("Mat2", "Mat4", "p4", 'M');
		print_file(jama_mat_24, jama_file_24);

		//mat_3 * mat_4
		Matrix jama_mat_34 = jama_mat_3.times(jama_mat_4);
		File jama_file_34 = create_output_file("Mat3", "Mat4", "p4", 'M');
		print_file(jama_mat_34, jama_file_34);

		//mat_4 * mat_3
		Matrix jama_mat_43 = jama_mat_4.times(jama_mat_3);
		File jama_file_43 = create_output_file("Mat4", "Mat3", "p4", 'M');
		print_file(jama_mat_43, jama_file_43);

	}//end jama_multiplying_flow method

	
	//4 methods to load each Matrix object
	public void load_jama_mat_1() {		
		//Initialize an empty Matrix object with mat_1's dimensions
		jama_mat_1 = new Matrix(mat_1.size(), mat_1.get(0).size());

		//Copy data into the Matrix
		for(int r = 0; r < jama_mat_1.getRowDimension(); r++) {
			for(int c = 0; c < jama_mat_1.getColumnDimension(); c++) {
				jama_mat_1.set(r, c, mat_1.get(r).get(c).doubleValue());
			}
		}

	}//end load_jama_mat_1

	public void load_jama_mat_2() {		
		//Initialize an empty Matrix object with mat_2's dimensions
		jama_mat_2 = new Matrix(mat_2.size(), mat_2.get(0).size());

		//Copy data into the Matrix
		for(int r = 0; r < jama_mat_2.getRowDimension(); r++) {
			for(int c = 0; c < jama_mat_2.getColumnDimension(); c++) {
				jama_mat_2.set(r, c, mat_2.get(r).get(c).doubleValue());
			}
		}
	}//end load_jama_mat_2

	public void load_jama_mat_3() {		
		//Initialize an empty Matrix object with mat_3's dimensions
		jama_mat_3 = new Matrix(mat_3.size(), mat_3.get(0).size());

		//Copy data into the Matrix
		for(int r = 0; r < jama_mat_3.getRowDimension(); r++) {
			for(int c = 0; c < jama_mat_3.getColumnDimension(); c++) {
				jama_mat_3.set(r, c, mat_3.get(r).get(c).doubleValue());
			}
		}	
	}//end load_jama_mat_3

	public void load_jama_mat_4() {		
		//Initialize an empty Matrix object with mat_4's dimensions
		jama_mat_4 = new Matrix(mat_4.size(), mat_4.get(0).size());

		//Copy data into the Matrix
		for(int r = 0; r < jama_mat_4.getRowDimension(); r++) {
			for(int c = 0; c < jama_mat_4.getColumnDimension(); c++) {
				jama_mat_4.set(r, c, mat_4.get(r).get(c).doubleValue());
			}
		}
	}//end load_jama_mat_4


	
	//Print a 2D matrix to a file.
	public void print_file(Matrix matrix, File file) {
		try {
			FileWriter fw = new FileWriter(file);
			fw.write("Andy = 4\nBruce = 5\n\n");

			for(int r = 0; r < matrix.getRowDimension(); r++) {
				for(int c = 0; c < matrix.getColumnDimension(); c++) {
					fw.write(matrix.get(r,c) + " ");
				}//end inner for loop
				fw.write("\n");
			}//end outer for loop

			fw.close();
			System.out.println("Data written to file \"" + file.getName() + "\"");
		}catch(IOException io) {
			System.out.println("\nIO Exception in print_file method:\nMatrix:");
			print_console(matrix);
		}//end try/catch block

	}//end print_file (Matrix) method

	//Print a 2D matrix to console for testing.
	public void print_console(Matrix matrix) {
		System.out.println("\nAndy = 4\nBruce = 5");

		for(int r = 0; r < matrix.getRowDimension(); r++) {
			for(int c = 0; c < matrix.getColumnDimension(); c++) {
				System.out.print(matrix.get(r,c) + " ");
			}//end inner for loop
			System.out.println();
		}//end outer for loop
	}//end print_console (Matrix) method

	//Create a new File with corresponding name if a letter is needed
	public File create_output_file(String mat_name_1, String mat_name_2, String part_name, char calculation) {
		String suffix = "";

		//Decide on the letter in the suffix
		suffix += calculation;
		suffix = suffix.toUpperCase();

		//Decide on the first number in the file name's suffix
		if(mat_name_1.equalsIgnoreCase("Mat1")) {
			suffix += "1";
		}else if (mat_name_1.equalsIgnoreCase("Mat2")) {
			suffix += "2";
		}else if (mat_name_1.equalsIgnoreCase("Mat3")) {
			suffix += "3";
		}else if (mat_name_1.equalsIgnoreCase("Mat4")) {
			suffix += "4";
		}else {
			suffix += mat_name_1;
		}

		//Decide on the second number in the file name's suffix
		if(mat_name_2.equalsIgnoreCase("Mat1")) {
			suffix += "1";
		}else if(mat_name_2.equalsIgnoreCase("Mat2")) {
			suffix += "2";
		}else if(mat_name_2.equalsIgnoreCase("Mat3")) {
			suffix += "3";
		}else if(mat_name_2.equalsIgnoreCase("Mat4")) {
			suffix += "4";
		}else {
			suffix += mat_name_2;
		}

		return new File("abruce_"+ part_name + "_out" + suffix + ".txt");
	}//end create_output_file (String, String, String, char) method


	//Convert file data into 2D ArrayList
	public ArrayList<ArrayList<Number>> read_file(File file){
		try {
			ArrayList<ArrayList<Number>> temp_mat = new ArrayList<ArrayList<Number>>();
			Scanner reader = new Scanner(file);

			while(reader.hasNextLine()) {
				String line = reader.nextLine();

				if(line.contains("Andy = 4") || line.contains("Bruce = 5") || line.equalsIgnoreCase("")) {
					//Handles if the line is the header
					continue;
				}else {
					//Create a row for the matrix from the line
					ArrayList<Number> temp_row = new ArrayList<Number>();

					while(line.length() > 0) {
						//Isolate the first number, if the line has a space
						String sub_str = "";
						if(line.contains(" ")) {
							int space_index = line.indexOf(' ');
							sub_str = line.substring(0, space_index);
						}else {
							//Likely dealing with the last number in a line
							sub_str = line;
						}

						//Account for doubles and ints
						if(sub_str.contains(".")) {
							temp_row.add((Number)Double.parseDouble(sub_str));
						}else {
							temp_row.add((Number)Integer.parseInt(sub_str));
						}	

						//Remove the number from the line
						line = line.replaceFirst(sub_str, "");
						line = line.strip();
					}//end inner while loop

					//Add the row
					temp_mat.add(temp_row);
				}//end if/else block
			}//end outer while loop

			return temp_mat;
		}catch(FileNotFoundException fnf) {
			System.out.println("\nFile missing in read file step: "+ file.getName());
			return null;
		}//end try/catch block
	}//end read_file

}//end abruce_p4 class
