package abruce_package;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileNotFoundException;

public class abruce_p2 {

	private ArrayList<ArrayList<Number>> mat_1;
	private ArrayList<ArrayList<Number>> mat_2;
	private ArrayList<ArrayList<Number>> mat_3;
	private ArrayList<ArrayList<Number>> mat_4;
	private ArrayList<File> output_files;

	public abruce_p2(File f1, File f2, File f3, File f4) {
		//Load the matrices
		mat_1 = read_file(f1);
		mat_2 = read_file(f2);
		mat_3 = read_file(f3);
		mat_4 = read_file(f4);

		output_files = new ArrayList<File>();
	}

	public void logic() {
		//Prompt, check, add, and write matrices as long as the user wants.
		boolean loop_again = true;

		do {
			//Ask if the user would like to test matrices
			System.out.println("\nWould you like to add matrices?"
					+ "\nEnter Y for yes or N for no: ");
			Scanner input = new Scanner(System.in);
			String response = input.nextLine().strip();
			if(response.equalsIgnoreCase("n") || response.equalsIgnoreCase("no")) {
				loop_again = false;
				continue;	//exits the loop
			}else if(response.equalsIgnoreCase("y") || response.equalsIgnoreCase("yes")){
				loop_again = true;
			}else {
				continue;
			}

			boolean acceptable_names = false;
			boolean matching_sizes = false;;

			//Prompt for matrices
			System.out.println("\nThe following prompts refer to matrix addition:");
			String first_mat_name = prompt_first_mat();
			String second_mat_name = prompt_second_mat();

			//If user choices are existing matrices, then change acceptable_names = true. If not, then continue to next iteration and ask again.
			if(check_existing(first_mat_name) && check_existing(second_mat_name)) {
				acceptable_names = true;
			}else {
				System.out.println("\nInvalid name choice(s). Try again.");
				continue;
			}

			//Create temporary ArrayLists after confirming there is a corresponding matrix.
			ArrayList<ArrayList<Number>> temp_a = give_corresponding_matrix(first_mat_name);
			ArrayList<ArrayList<Number>> temp_b = give_corresponding_matrix(second_mat_name);

			//If matrices match dimensions, then change matching_sizes = true. If not, then continue to next iteration.
			if(check_dimensions_adding(temp_a, temp_b)) {
				matching_sizes = true;
			}else {
				System.out.println("\nMismatched matrix dimensions: "
						+ "\n	First matrix: " + temp_a.size() + " by " + temp_a.get(0).size()
						+ "\n	Second matrix: " + temp_b.size() + " by " + temp_b.get(0).size());
				continue;
			}

			ArrayList<ArrayList<Number>> matrix_summed;
			//If both names and dimensions are acceptable, do the addition. If not, keep looping.
			if(acceptable_names && matching_sizes) {
				matrix_summed = add_mats(temp_a, temp_b);
			}else {
				System.out.println("\nEither dimensionality, names, or both are unacceptable.");
				continue;
			}

			//Write the new matrix to the corresponding file
			File temp_file = create_output_file(first_mat_name, second_mat_name, "p2");
			print_file(matrix_summed, temp_file);
			output_files.add(temp_file);
			
		}while(loop_again);
		System.out.println("\nPart 2's adding loop has been exited.");
	}//end abruce_p2 method

	//Check if adding can be done with the specified matrices.
	public boolean check_dimensions_adding(ArrayList<ArrayList<Number>> matrix_a, ArrayList<ArrayList<Number>> matrix_b) {
		int mat_a_rows = 0;
		int mat_a_cols = 0;
		int mat_b_rows = 0;
		int mat_b_cols = 0;

		try {
			mat_a_rows = matrix_a.size();
			mat_a_cols = matrix_a.get(0).size();
			mat_b_rows = matrix_b.size();
			mat_b_cols = matrix_b.get(0).size();
		}catch(IndexOutOfBoundsException ind) {
			System.out.println("Checked an index that doesn't exist in check_dimensions method.");
		}//end try/catch block

		return (mat_a_rows == mat_b_rows) && (mat_a_cols == mat_b_cols);
	}//end check_dimensions method

	//Add the matrices. Make everything a wrapped Double, converted to a Number
	public ArrayList<ArrayList<Number>> add_mats(ArrayList<ArrayList<Number>> mat_a, ArrayList<ArrayList<Number>> mat_b) {
		ArrayList<ArrayList<Number>> mat_c = new ArrayList<ArrayList<Number>>();

		for(int r = 0; r < mat_a.size(); r++) {
			ArrayList<Number> temp = new ArrayList<Number>();
			for(int c = 0; c < mat_a.get(r).size(); c++) {
				temp.add((Number) ((Double)(mat_a.get(r).get(c).doubleValue() + mat_b.get(r).get(c).doubleValue())));
			}
			mat_c.add(temp);
		}

		return mat_c;
	}//end add_mats method

	//If the name matches an existing matrix, return the corresponding matrix.
	public ArrayList<ArrayList<Number>> give_corresponding_matrix(String matched_mat_name) {
		if(matched_mat_name.equalsIgnoreCase("Mat1")) { 
			return mat_1;
		}else if(matched_mat_name.equalsIgnoreCase("Mat2")) {
			return mat_2;
		}else if(matched_mat_name.equalsIgnoreCase("Mat3")) {
			return mat_3;
		}else if(matched_mat_name.equalsIgnoreCase("Mat4")) {
			return mat_4;
		}else {
			//If, for some reason, this is accessed, make a note and return an empty ArrayList<ArrayList<Number>>.
			ArrayList<ArrayList<Number>> empty = new ArrayList<ArrayList<Number>>();
			System.out.println("\nError in the give_corresponding_matrix method: bad name made it through.");
			return empty;
		}//end if/else block
	}//end give_corresponding method

	//Check if the given name corresponds to an existing matrix or vector.
	public boolean check_existing(String name) {
		if(name.equalsIgnoreCase("Mat1") || name.equalsIgnoreCase("Mat2") 
				|| name.equalsIgnoreCase("Mat3") || name.equalsIgnoreCase("Mat4")) {
			return true;
		}
		return false;
	}//end check_existing method

	//Prompt the user for the first matrix to add
	public String prompt_first_mat(){
		Scanner input = new Scanner(System.in);
		System.out.println("\nPlease enter the first matrix that you wish to use."
				+ "\n(Options: Mat1, Mat2, Mat3, Mat4): ");
		String temp = input.next();
		return temp.strip();
	}//end prompt_first_mat method

	//Prompt the user for the second matrix to add
	public String prompt_second_mat(){
		Scanner input = new Scanner(System.in);
		System.out.println("\nPlease enter the second matrix that you wish to use."
				+ "\n(Options: Mat1, Mat2, Mat3, Mat4): ");
		String temp = input.next();
		return temp.strip();
	}//end prompt_second_mat method

	//Create a new File with corresponding name	
	public File create_output_file(String mat_name_1, String mat_name_2, String part_name) {
		String suffix = "";

		//Decide on the first number in the file name's suffix
		if(mat_name_1.equalsIgnoreCase("Mat1")) {
			suffix += "1";
		}else if (mat_name_1.equalsIgnoreCase("Mat2")) {
			suffix += "2";
		}else if (mat_name_1.equalsIgnoreCase("Mat3")) {
			suffix += "3";
		}else if (mat_name_1.equalsIgnoreCase("Mat4")) {
			suffix += "4";
		}else {
			suffix += mat_name_1;
		}

		//Decide on the second number in the file name's suffix
		if(mat_name_2.equalsIgnoreCase("Mat1")) {
			suffix += "1";
		}else if(mat_name_2.equalsIgnoreCase("Mat2")) {
			suffix += "2";
		}else if(mat_name_2.equalsIgnoreCase("Mat3")) {
			suffix += "3";
		}else if(mat_name_2.equalsIgnoreCase("Mat4")) {
			suffix += "4";
		}else {
			suffix += mat_name_2;
		}

		return new File("abruce_"+ part_name +"_out" + suffix + ".txt");
	}//end create_output_file (String, String, String) method

	

	//Convert file data into 2D ArrayList
	public ArrayList<ArrayList<Number>> read_file(File file){
		try {
			ArrayList<ArrayList<Number>> temp_mat = new ArrayList<ArrayList<Number>>();
			Scanner reader = new Scanner(file);

			while(reader.hasNextLine()) {
				String line = reader.nextLine();

				if(line.contains("Andy = 4") || line.contains("Bruce = 5") 
						|| line.equalsIgnoreCase("") || line.equalsIgnoreCase(" ")) {
					//Handles if the line is the header
					continue;
				}else {
					//Create a row for the matrix from the line
					ArrayList<Number> temp_row = new ArrayList<Number>();

					while(line.length() > 0) {
						//Isolate the first number, if the line has a space
						String sub_str = "";
						if(line.contains(" ")) {
							int space_index = line.indexOf(' ');
							sub_str = line.substring(0, space_index);
						}else {
							//Likely dealing with the last number in a line
							sub_str = line;
						}
						
						//Account for doubles and ints
						if(sub_str.contains(".")) {
							temp_row.add((Number)Double.parseDouble(sub_str));
						}else {
							temp_row.add((Number)Integer.parseInt(sub_str));
						}	
						
						//Remove the number from the line
						line = line.replaceFirst(sub_str, "");
						line = line.strip();
					}//end inner while loop

					//Add the row
					temp_mat.add(temp_row);
				}//end if/else block
			}//end outer while loop

			return temp_mat;
		}catch(FileNotFoundException fnf) {
			System.out.println("\nFile missing in read file step: "+ file.getName());
			return null;
		}//end try/catch block
	}//end read_file

	
	
	//Print to file
	public void print_file(ArrayList<ArrayList<Number>> matrix, File file) {
		try {
			FileWriter fw = new FileWriter(file);
			fw.write("Andy = 4\nBruce = 5\n\n");

			for(int r = 0; r < matrix.size(); r++) {
				for(int c = 0; c < matrix.get(r).size(); c++) {
					fw.write(matrix.get(r).get(c).toString() + " ");
				}//end inner for loop
				fw.write("\n");
			}//end outer for loop

			fw.close();
			System.out.println("Data written to file \"" + file.getName() + "\"");
		}catch(IOException io) {
			System.out.println("\nIO Exception in print_file method:\nMatrix:");
			print_console(matrix);
		}//end try/catch block

	}//end print_file method

	//Print to console (good for testing)
	public void print_console(ArrayList<ArrayList<Number>> matrix) {
		System.out.println("\nAndy = 4\nBruce = 5");

		for(int r = 0; r < matrix.size(); r++) {
			for(int c = 0; c < matrix.get(r).size(); c++) {
				System.out.print(matrix.get(r).get(c) + " ");
			}//end inner for loop
			System.out.println();
		}//end outer for loop
	}//end print_console method

	public ArrayList<File> share_files() {
		return output_files;
	}//end share_file method

}//end abruce_p2 class
