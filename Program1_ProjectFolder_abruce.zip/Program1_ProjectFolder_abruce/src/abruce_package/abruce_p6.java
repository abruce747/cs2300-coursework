package abruce_package;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class abruce_p6 {

	private ArrayList<ArrayList<Number>> mat_1;
	private ArrayList<ArrayList<Number>> mat_2;
	private ArrayList<ArrayList<Number>> mat_3;
	private ArrayList<ArrayList<Number>> mat_4;

	public abruce_p6(File f1, File f2, File f3, File f4) {
		//Load the matrices
		mat_1 = read_file(f1);
		mat_2 = read_file(f2);
		mat_3 = read_file(f3);
		mat_4 = read_file(f4);
	}//end constructor

	public void logic() {
		//Print transposed matrices to files
		print_file(transpose_matrix(mat_1), create_output_file("1", "p6"));
		print_file(transpose_matrix(mat_2), create_output_file("2", "p6"));
		print_file(transpose_matrix(mat_3), create_output_file("3", "p6"));
		print_file(transpose_matrix(mat_4), create_output_file("4", "p6"));
	}//end logic method

	//Print a 2D matrix to a file.
	public void print_file(ArrayList<ArrayList<Number>> matrix, File file) {
		try {
			FileWriter fw = new FileWriter(file);
			fw.write("Andy = 4\nBruce = 5\n\n");

			for(int r = 0; r < matrix.size(); r++) {
				for(int c = 0; c < matrix.get(r).size(); c++) {
					fw.write(matrix.get(r).get(c).toString() + " ");
				}//end inner for loop
				fw.write("\n");
			}//end outer for loop

			fw.close();
			System.out.println("Data written to file \"" + file.getName() + "\"");
		}catch(IOException io) {
			System.out.println("\nIO Exception in print_file method:\nMatrix:");
			print_console(matrix);
		}//end try/catch block

	}//end print_file method

	public File create_output_file(String input_name, String part) {
		return new File("abruce_"+ part +"_mat" + input_name + ".txt");
	}//end create_output_file method

	public ArrayList<ArrayList<Number>> transpose_matrix(ArrayList<ArrayList<Number>> orig_mat){
		ArrayList<ArrayList<Number>> new_mat = new ArrayList<ArrayList<Number>>();

		//Load the new matrix to be empty so that indices can be set later
		for(int new_rows = 0; new_rows < orig_mat.get(0).size(); new_rows++) {
			ArrayList<Number> row = new ArrayList<Number>();

			for(int new_cols = 0; new_cols < orig_mat.size(); new_cols++) {
				row.add((Number)0.0);
			}//end inner loop

			new_mat.add(row);
		}//end outer loop


		//Each row in the original becomes the corresponding numbered column in the resulting matrix 
		for(int new_rows = 0; new_rows < new_mat.size(); new_rows++) {
			for(int new_cols = 0; new_cols < new_mat.get(new_rows).size(); new_cols++) {
				Number value = orig_mat.get(new_cols).get(new_rows);
				new_mat.get(new_rows).set(new_cols, value);
			}//end inner loop
		}//end outer loop

		return new_mat;
	}

	//Convert file data into 2D ArrayList
	public ArrayList<ArrayList<Number>> read_file(File file){
		try {
			ArrayList<ArrayList<Number>> temp_mat = new ArrayList<ArrayList<Number>>();
			Scanner reader = new Scanner(file);

			while(reader.hasNextLine()) {
				String line = reader.nextLine();

				if(line.contains("Andy = 4") || line.contains("Bruce = 5") || line.equalsIgnoreCase("")) {
					//Handles if the line is the header
					continue;
				}else {
					//Create a row for the matrix from the line
					ArrayList<Number> temp_row = new ArrayList<Number>();

					while(line.length() > 0) {
						//Isolate the first number, if the line has a space
						String sub_str = "";
						if(line.contains(" ")) {
							int space_index = line.indexOf(' ');
							sub_str = line.substring(0, space_index);
						}else {
							//Likely dealing with the last number in a line
							sub_str = line;
						}

						//Account for doubles and ints
						if(sub_str.contains(".")) {
							temp_row.add((Number)Double.parseDouble(sub_str));
						}else {
							temp_row.add((Number)Integer.parseInt(sub_str));
						}	

						//Remove the number from the line
						line = line.replaceFirst(sub_str, "");
						line = line.strip();
					}//end inner while loop

					//Add the row
					temp_mat.add(temp_row);
				}//end if/else block
			}//end outer while loop

			return temp_mat;
		}catch(FileNotFoundException fnf) {
			System.out.println("\nFile missing in read file step: "+ file.getName());
			return null;
		}//end try/catch block
	}//end read_file

	//Print a 2D matrix to console for testing.
	public void print_console(ArrayList<ArrayList<Number>> matrix) {
		System.out.println("\nAndy = 4\nBruce = 5");

		for(int r = 0; r < matrix.size(); r++) {
			for(int c = 0; c < matrix.get(r).size(); c++) {
				System.out.print(matrix.get(r).get(c) + " ");
			}//end inner for loop
			System.out.println();
		}//end outer for loop
	}//end print_console method

}//end abruce_p6 class
