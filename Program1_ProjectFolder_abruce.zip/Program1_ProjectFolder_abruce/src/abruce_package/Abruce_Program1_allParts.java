package abruce_package;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import Jama.Matrix;

public class Abruce_Program1_allParts {

	private ArrayList<ArrayList<Number>> mat_1;
	private ArrayList<ArrayList<Number>> mat_2;
	private ArrayList<ArrayList<Number>> mat_3;
	private ArrayList<ArrayList<Number>> mat_4;

	private final int FIRST = 4;//Andy
	private final int LAST = 5;//Bruce

	private Vector vec_r;
	private Vector vec_s;
	private Vector vec_u;
	private Vector vec_v;
	private Vector vec_w;

	//Instance variables using my chosen library from https://math.nist.gov/javanumerics/jama/doc/Jama/package-summary.html
	private Matrix jama_mat_1;
	private Matrix jama_mat_2;
	private Matrix jama_mat_3;
	private Matrix jama_mat_4;

//	private Matrix jama_vec_r;
//	private Matrix jama_vec_s;
//	private Matrix jama_vec_u;
//	private Matrix jama_vec_v;
//	private Matrix jama_vec_w;

	//Initialize data to be ready for any step
	public Abruce_Program1_allParts() {
		mat_1 = new ArrayList<ArrayList<Number>>();
		mat_2 = new ArrayList<ArrayList<Number>>();
		mat_3 = new ArrayList<ArrayList<Number>>();
		mat_4 = new ArrayList<ArrayList<Number>>();

		fill_mat1();
		fill_mat2();
		fill_mat3();
		fill_mat4();

		load_jama_mat_1();
		load_jama_mat_2();
		load_jama_mat_3();
		load_jama_mat_4();

		vec_r = new Vector(-1, -2);
		vec_s = new Vector(-3, 3);
		vec_u = new Vector(2, -1);
		vec_v = new Vector(3, 1);
		vec_w = new Vector(1, 3);

//		jama_vec_r = new Matrix(vec_r.get_vec());
//		jama_vec_s = new Matrix(vec_s.get_vec());
//		jama_vec_u = new Matrix(vec_u.get_vec());
//		jama_vec_v = new Matrix(vec_v.get_vec());
//		jama_vec_w = new Matrix(vec_w.get_vec());
	}//end constructor




	//Part 1's code=========================================================================

	public void abruce_p1() {
		File file_1 = new File("abruce_mat1.txt");
		File file_2 = new File("abruce_mat2.txt");
		File file_3 = new File("abruce_mat3.txt");
		File file_4 = new File("abruce_mat4.txt");

		print_file(mat_1, file_1);
		print_file(mat_2, file_2);
		print_file(mat_3, file_3);
		print_file(mat_4, file_4);
	}//end abruce_p1 method

	//Mat1 method
	public void fill_mat1() {
		int value = 1;
		//Num rows = LAST. Num cols = FIRST
		for(int r = 0; r < LAST; r++) {
			//Create and load an ArrayList
			ArrayList<Number> temp = new ArrayList<Number>();

			for(int c = 0; c < FIRST; c++) {
				temp.add((Integer)value);
				value++;
			}//end inner for loop

			mat_1.add(temp);
		}//end outer for loop
	}//end fill_mat1 method

	//Mat2 method
	public void fill_mat2() {
		int value = 2;

		//Num rows = LAST. Num cols = FIRST 
		for(int c = 0; c < FIRST; c++) {
			ArrayList<Number> temp = new ArrayList<Number>();

			for(int r = 0; r < LAST; r++) {
				temp.add((Integer)value);
				value += 3;
			}//end inner loop

			mat_2.add(temp);
		}//end outer loop
	}//end fill_mat2 method

	//Mat3 method
	public void fill_mat3() {
		int value = 10;

		//Num rows = 2. Num cols = 4
		for(int r = 0; r < 2; r++) {
			ArrayList<Number> temp = new ArrayList<Number>();

			for(int c = 0; c < 4; c++) {
				temp.add((Integer)value);
				value -= 2;
			}//end inner loop

			mat_3.add(temp);
		}//end outer loop
	}//end fill_mat3 method

	//Mat4 method
	public void fill_mat4() {
		double value = -6.0;

		//Num rows = 4. Num cols = 2.
		for(int c = 0; c < 2; c++) {
			ArrayList<Number> temp = new ArrayList<Number>();

			for(int r = 0; r < 4; r++) {
				temp.add((Double)value);
				value += 1.5;
			}//end inner for loop

			mat_4.add(temp);
		}//end outer for loop
	}//end fill_mat4 method




	//Part 2's code=========================================================================

	public void abruce_p2() {
		//Prompt, check, add, and write matrices as long as the user wants.
		boolean loop_again = true;

		do {
			//Ask if the user would like to test matrices
			System.out.println("\nWould you like to add matrices?"
					+ "\nEnter Y for yes or N for no: ");
			Scanner input = new Scanner(System.in);
			String response = input.nextLine().strip();
			if(response.equalsIgnoreCase("n") || response.equalsIgnoreCase("no")) {
				loop_again = false;
				continue;	//exits the loop
			}else if(response.equalsIgnoreCase("y") || response.equalsIgnoreCase("yes")){
				loop_again = true;
			}else {
				continue;
			}

			boolean acceptable_names = false;
			boolean matching_sizes = false;;

			//Prompt for matrices
			System.out.println("\n\nThe following prompts refer to matrix addition:");
			String first_mat_name = prompt_first_mat();
			String second_mat_name = prompt_second_mat();

			//If user choices are existing matrices, then change acceptable_names = true. If not, then continue to next iteration and ask again.
			if(check_existing(first_mat_name) && check_existing(second_mat_name)) {
				acceptable_names = true;
			}else {
				System.out.println("\nInvalid name choice(s). Try again.");
				continue;
			}

			//Create temporary ArrayLists after confirming there is a corresponding matrix.
			ArrayList<ArrayList<Number>> temp_a = give_corresponding_matrix(first_mat_name);
			ArrayList<ArrayList<Number>> temp_b = give_corresponding_matrix(second_mat_name);

			//If matrices match dimensions, then change matching_sizes = true. If not, then continue to next iteration.
			if(check_dimensions_adding(temp_a, temp_b)) {
				matching_sizes = true;
			}else {
				System.out.println("\nMismatched matrix dimensions: "
						+ "\n	First matrix: " + temp_a.size() + " by " + temp_a.get(0).size()
						+ "\n	Second matrix: " + temp_b.size() + " by " + temp_b.get(0).size());
				continue;
			}

			ArrayList<ArrayList<Number>> matrix_summed;
			//If both names and dimensions are acceptable, do the addition. If not, keep looping.
			if(acceptable_names && matching_sizes) {
				matrix_summed = add_mats(temp_a, temp_b);
			}else {
				System.out.println("\nEither dimensionality, names, or both are unacceptable.");
				continue;
			}

			//Write the new matrix to the corresponding file
			print_file(matrix_summed, create_output_file(first_mat_name, second_mat_name, "p2"));

		}while(loop_again);
		System.out.println("\nPart 2's adding loop has been exited.");
	}//end abruce_p2 method

	//Check if adding can be done with the specified matrices.
	public boolean check_dimensions_adding(ArrayList<ArrayList<Number>> matrix_a, ArrayList<ArrayList<Number>> matrix_b) {
		int mat_a_rows = 0;
		int mat_a_cols = 0;
		int mat_b_rows = 0;
		int mat_b_cols = 0;

		try {
			mat_a_rows = matrix_a.size();
			mat_a_cols = matrix_a.get(0).size();
			mat_b_rows = matrix_b.size();
			mat_b_cols = matrix_b.get(0).size();
		}catch(IndexOutOfBoundsException ind) {
			System.out.println("Checked an index that doesn't exist in check_dimensions method.");
		}//end try/catch block

		return (mat_a_rows == mat_b_rows) && (mat_a_cols == mat_b_cols);
	}//end check_dimensions method

	//Add the matrices. Make everything a wrapped Double, converted to a Number
	public ArrayList<ArrayList<Number>> add_mats(ArrayList<ArrayList<Number>> mat_a, ArrayList<ArrayList<Number>> mat_b) {
		ArrayList<ArrayList<Number>> mat_c = new ArrayList<ArrayList<Number>>();

		for(int r = 0; r < mat_a.size(); r++) {
			ArrayList<Number> temp = new ArrayList<Number>();
			for(int c = 0; c < mat_a.get(r).size(); c++) {
				temp.add((Number) ((Double)(mat_a.get(r).get(c).doubleValue() + mat_b.get(r).get(c).doubleValue())));
			}
			mat_c.add(temp);
		}

		return mat_c;
	}//end add_mats method



	//Part 3's code=========================================================================
	public void abruce_p3() {
		//Prompt, check, multiply, and write matrices as long as the user wants.
		boolean loop_again = true;

		do {
			//Ask if the user would like to test any matrices
			System.out.println("\nWould you like to multiply matrices?"
					+ "\nEnter Y for yes or N for no: ");
			Scanner input = new Scanner(System.in);
			String response = input.nextLine().strip();
			if(response.equalsIgnoreCase("n") || response.equalsIgnoreCase("no")) {
				loop_again = false;
				continue;	//exits the loop
			}else if(response.equalsIgnoreCase("y") || response.equalsIgnoreCase("yes")){
				loop_again = true;
			}else {
				continue;
			}

			boolean acceptable_names = false;
			boolean matching_sizes = false;;

			//Prompt for matrices
			System.out.println("/nThe following prompts refer to matrix multiplication:");
			String first_mat_name = prompt_first_mat();
			String second_mat_name = prompt_second_mat();

			//If user choices are existing matrices, then change acceptable_names = true. If not, then continue to next iteration and ask again.
			if(check_existing(first_mat_name) && check_existing(second_mat_name)) {
				acceptable_names = true;
			}else {
				System.out.println("\nInvalid name choice(s). Try again.");
				continue;
			}

			//Create temporary ArrayLists after confirming there is a corresponding matrix.
			ArrayList<ArrayList<Number>> mat_a = give_corresponding_matrix(first_mat_name);
			ArrayList<ArrayList<Number>> mat_b = give_corresponding_matrix(second_mat_name);

			//If matrices match dimensions, then change matching_sizes = true. If not, then continue to next iteration.
			if(check_dimensions_multiplying(mat_a, mat_b)) {
				matching_sizes = true;
			}else {
				System.out.println("\nMismatched matrix dimensions: "
						+ "\n	First matrix: " + mat_a.size() + " by " + mat_a.get(0).size()
						+ "\n	Second matrix: " + mat_b.size() + " by " + mat_b.get(0).size());
				continue;
			}

			ArrayList<ArrayList<Number>> matrix_multiplied;
			//If both names and dimensions are acceptable, do the multiplication. If not, keep looping.
			if(acceptable_names && matching_sizes) {
				matrix_multiplied = multiply_mats(mat_a, mat_b);
			}else {
				System.out.println("\nEither dimensionality, names, or both are unacceptable.");
				continue;
			}

			//Write the new matrix to the corresponding file
			print_file(matrix_multiplied, create_output_file(first_mat_name, second_mat_name, "p3"));

		}while(loop_again);
		System.out.println("\nPart 3's multiplying loop has been exited.");
	}//end abruce_p3 method

	public boolean check_dimensions_multiplying(ArrayList<ArrayList<Number>> mat_a, ArrayList<ArrayList<Number>> mat_b) {
		//Assume mat_a dimensions mXn and mat_b dimensions oXp  (rowXcol)
		int mat_a_cols = mat_a.get(0).size();
		int mat_b_rows = mat_b.size();

		//Check dimensions
		if(mat_a_cols == mat_b_rows) {
			return true;
		}else {
			return false;
		}
	}//end check_dimensions_multiplying method

	public ArrayList<ArrayList<Number>> multiply_mats(ArrayList<ArrayList<Number>> mat_a, ArrayList<ArrayList<Number>> mat_b){
		//Assume mat_a dimensions mXn and mat_b dimensions oXp  (rowXcol). Assume n == o
		ArrayList<ArrayList<Number>> mat_c = new ArrayList<ArrayList<Number>>();

		//Resulting matrix will be of size mXp
		int c_row = mat_a.size();
		int c_col = mat_b.get(0).size();

		//Iterate through mat_c
		for(int row = 0; row < c_row; row++) {
			//Load temporary ArrayList
			ArrayList<Number> temp_c_row = new ArrayList<Number>();

			for(int col = 0; col < c_col; col++) {
				ArrayList<Number> b_col = new ArrayList<Number>();
				for(int b_rows = 0; b_rows < mat_b.size(); b_rows++) {
					b_col.add(mat_b.get(b_rows).get(col));
				}//end first for loop
				//∀ indices x ɛ mat_c, dot product uses mat_a's corresponding row and mat_b's corresponding column	
				temp_c_row.add((Number) ((Double)dot_product(mat_a.get(row), b_col)));
			}//end second for loop

			mat_c.add(temp_c_row);
		}//end third for loop

		return mat_c;
	}//end multiply_mats method

	public double dot_product(ArrayList<Number> row, ArrayList<Number> col) {
		double scalar = 0.0;

		//Can assume that row.size() == col.size(), so can iterate both simultaneously
		for(int r = 0; r < row.size(); r++) {
			scalar += row.get(r).doubleValue() * col.get(r).doubleValue();
		}

		return scalar;
	}//end dot_prod method




	//Part 4's code=========================================================================

	public void abruce_p4() {
		//Use NIST jar file to do the adding and multiplying from parts 2 and 3.
		//Save them to their own files of format abruce_p4_outA12 for adding mat 1 and mat 2.
		//abruce_p4_outM13 for multiplying matrices 1 and 3

		//Matrix addition step
		jama_adding_flow();
		//Matrix multiplication step
		jama_multiplying_flow();
	}//end abruce_p4 method

	//Handle the replication of part 2, but without user input
	public void jama_adding_flow() {
		//Code should check all possible combinations
		//Only matrices that can be added are Mat3 and Mat4
		Matrix jama_mat_34 = jama_mat_3.plus(jama_mat_4);
		//Write it to a file
		File jama_file_34 = create_output_file("Mat3", "Mat4", "p4", 'A');
		print_file(jama_mat_34, jama_file_34);
	}//end jama_adding_flow method

	public void jama_multiplying_flow() {
		//Code should check all possible combinations with the JAMA jar file
		//Only matrices that can be multiplied in pairs are:
		//mat_1(mat_2), mat_2(mat_1), mat_3(mat_2), mat_4(mat_2)

		//mat_1 * mat_2
		Matrix jama_mat_12 = jama_mat_1.times(jama_mat_2);
		File jama_file_12 = create_output_file("Mat1", "Mat2", "p4", 'M');
		print_file(jama_mat_12, jama_file_12);

		//mat_2 * mat_1
		Matrix jama_mat_21 = jama_mat_2.times(jama_mat_1);
		File jama_file_21 = create_output_file("Mat2", "Mat1", "p4", 'M');
		print_file(jama_mat_21, jama_file_21);

		//mat_3 * mat_2
		Matrix jama_mat_32 = jama_mat_3.times(jama_mat_2);
		File jama_file_32 = create_output_file("Mat3", "Mat2", "p4", 'M');
		print_file(jama_mat_32, jama_file_32);

		//mat_4 * mat_2
		Matrix jama_mat_42 = jama_mat_4.times(jama_mat_2);
		File jama_file_42 = create_output_file("Mat4", "Mat2", "p4", 'M');
		print_file(jama_mat_42, jama_file_42);
	}//end jama_multiplying_flow method



	//Part 5's code=========================================================================

	public void abruce_p5() {
		//Prompt, check, calculate, and write vectors as long as the user wants.
		boolean loop_again = true;

		do {
			//Ask if the user would like to test any vectors
			System.out.println("\nWould you like to calculate a dot product?"
					+ "\nEnter Y for yes or N for no: ");
			Scanner input = new Scanner(System.in);
			String response = input.nextLine().strip();
			if(response.equalsIgnoreCase("n") || response.equalsIgnoreCase("no")) {
				loop_again = false;
				continue;	//exits the loop
			}else if(response.equalsIgnoreCase("y") || response.equalsIgnoreCase("yes")){
				loop_again = true;
			}else {
				continue;
			}

			//Prompt for vectors
			System.out.println("/nThe following prompts refer to vector dot products:");
			String first_vec_name = prompt_first_vec();
			String second_vec_name = prompt_second_vec();

			//If user choice is invalid, then continue to next iteration and ask again.
			if(!(check_existing(first_vec_name) && check_existing(second_vec_name))) {
				System.out.println("\nInvalid name choice(s). Try again.");
				continue;
			}

			//Create temporary Vectors
			Vector vec_a = give_corresponding_vector(first_vec_name);
			Vector vec_b = give_corresponding_vector(second_vec_name);

			double product = vec_a.dot_product(vec_b);

			//Write the new matrix to the corresponding file
			print_file(product, create_output_file(first_vec_name, second_vec_name, "p5"));

		}while(loop_again);
		System.out.println("\nPart 5's dot product loop has been exited.");
	}//end abruce_p5 method


	//Part 6's code=========================================================================

	public void abruce_p6() {
		//Transpose original 4 matrices
		ArrayList<ArrayList<Number>> mat_1_t = transpose_matrix(mat_1);
		ArrayList<ArrayList<Number>> mat_2_t = transpose_matrix(mat_2);
		ArrayList<ArrayList<Number>> mat_3_t = transpose_matrix(mat_3);
		ArrayList<ArrayList<Number>> mat_4_t = transpose_matrix(mat_4);

		//Print them to files
		print_file(mat_1_t, create_output_file("1", "p6"));
		print_file(mat_2_t, create_output_file("2", "p6"));
		print_file(mat_3_t, create_output_file("3", "p6"));
		print_file(mat_4_t, create_output_file("4", "p6"));
	}//end abruce_p6 method

	public ArrayList<ArrayList<Number>> transpose_matrix(ArrayList<ArrayList<Number>> orig_mat){
		ArrayList<ArrayList<Number>> new_mat = new ArrayList<ArrayList<Number>>();

		//Load the new matrix to be empty so that indices can be set later
		for(int new_rows = 0; new_rows < orig_mat.get(0).size(); new_rows++) {
			ArrayList<Number> row = new ArrayList<Number>();

			for(int new_cols = 0; new_cols < orig_mat.size(); new_cols++) {
				row.add((Number)0.0);
			}//end inner loop

			new_mat.add(row);
		}//end outer loop


		//Each row in the original becomes the corresponding numbered column in the resulting matrix 
		for(int new_rows = 0; new_rows < new_mat.size(); new_rows++) {
			for(int new_cols = 0; new_cols < new_mat.get(new_rows).size(); new_cols++) {
				Number value = orig_mat.get(new_cols).get(new_rows);
				new_mat.get(new_rows).set(new_cols, value);
			}//end inner loop
		}//end outer loop

		return new_mat;
	}




	//Part 7's code=========================================================================
	public void abruce_p7() {
		//1.) Dot product (vectors represented by 2 by 1 matrix)
		jama_dot_product_flow();
		//2.) Transpose the four original Matrix objects
		jama_transpose_flow();
	}//end abruce_p7 method

	public void jama_dot_product_flow() {
		//Prompt, check, calculate, and write vectors as long as the user wants.
		boolean loop_again = true;
		do {
			//Ask if the user would like to test any vectors
			System.out.println("\nWould you like to calculate a dot product using the JAMA library?"
					+ "\nEnter Y for yes or N for no: ");
			Scanner input = new Scanner(System.in);
			String response = input.nextLine().strip();
			if(response.equalsIgnoreCase("n") || response.equalsIgnoreCase("no")) {
				loop_again = false;
				continue;	//exits the loop
			}else if(response.equalsIgnoreCase("y") || response.equalsIgnoreCase("yes")){
				loop_again = true;
			}else {
				continue;
			}

			//Prompt for vectors
			System.out.println("\nThe following prompts refer to vector dot products using JAMA:");
			String first_vec_name = prompt_first_vec();
			String second_vec_name = prompt_second_vec();

			//If user choice is invalid, then continue to next iteration and ask again.
			if(!(check_existing(first_vec_name) && check_existing(second_vec_name))) {
				System.out.println("\nInvalid name choice(s). Try again.");
				continue;
			}

			//Create temporary Vectors
			Vector vec_a = give_corresponding_vector(first_vec_name); // 2 by 1, need a 1 by 2
			Vector vec_b = give_corresponding_vector(second_vec_name); // 2 by 1

			//Convert the vectors to Jama matrix objects
			//Need to rotate the first vector matrix to enable multiplication
			double[][] vec_a_rotated = new double[1][2];
			vec_a_rotated[0][0] = vec_a.get_component_1();
			vec_a_rotated[0][1] = vec_a.get_component_2();
			
			Matrix vec_a_mat = new Matrix(vec_a_rotated);//now 1x2
			Matrix vec_b_mat = new Matrix(vec_b.get_vec());//2x1
			
			//Product of 1 by 2 and 2 by 1 gives 1 by 1 (scalar)
			Matrix product = vec_a_mat.times(vec_b_mat);
			
			//Write the new matrix to the corresponding file
			print_file(product, create_output_file(first_vec_name, second_vec_name, "p7", 'D'));

		}while(loop_again);
		System.out.println("\nPart 5's dot product loop has been exited.");
	}//end jama_dot_product_flow method

	public void jama_transpose_flow() {
		//No user input. Transpose all four original matrices
		Matrix jama_mat_1_t = jama_mat_1.transpose();
		Matrix jama_mat_2_t = jama_mat_2.transpose();
		Matrix jama_mat_3_t = jama_mat_3.transpose();
		Matrix jama_mat_4_t = jama_mat_4.transpose();
		
		//Print to files
		print_file(jama_mat_1_t, create_output_file("T","1","p7"));
		print_file(jama_mat_2_t, create_output_file("T","2","p7"));
		print_file(jama_mat_3_t, create_output_file("T","3","p7"));
		print_file(jama_mat_4_t, create_output_file("T","4","p7"));
	}//end jama_transpose_flow method
	
	
	
	//Auxiliary code=========================================================================



	//4 methods to load each Matrix object
	public void load_jama_mat_1() {		
		//Initialize an empty Matrix object with mat_1's dimensions
		jama_mat_1 = new Matrix(mat_1.size(), mat_1.get(0).size());

		//Copy data into the Matrix
		for(int r = 0; r < jama_mat_1.getRowDimension(); r++) {
			for(int c = 0; c < jama_mat_1.getColumnDimension(); c++) {
				jama_mat_1.set(r, c, mat_1.get(r).get(c).doubleValue());
			}
		}

	}//end load_jama_mat_1

	public void load_jama_mat_2() {		
		//Initialize an empty Matrix object with mat_2's dimensions
		jama_mat_2 = new Matrix(mat_2.size(), mat_2.get(0).size());

		//Copy data into the Matrix
		for(int r = 0; r < jama_mat_2.getRowDimension(); r++) {
			for(int c = 0; c < jama_mat_2.getColumnDimension(); c++) {
				jama_mat_2.set(r, c, mat_2.get(r).get(c).doubleValue());
			}
		}
	}//end load_jama_mat_2

	public void load_jama_mat_3() {		
		//Initialize an empty Matrix object with mat_3's dimensions
		jama_mat_3 = new Matrix(mat_3.size(), mat_3.get(0).size());

		//Copy data into the Matrix
		for(int r = 0; r < jama_mat_3.getRowDimension(); r++) {
			for(int c = 0; c < jama_mat_3.getColumnDimension(); c++) {
				jama_mat_3.set(r, c, mat_3.get(r).get(c).doubleValue());
			}
		}	
	}//end load_jama_mat_3

	public void load_jama_mat_4() {		
		//Initialize an empty Matrix object with mat_4's dimensions
		jama_mat_4 = new Matrix(mat_4.size(), mat_4.get(0).size());

		//Copy data into the Matrix
		for(int r = 0; r < jama_mat_4.getRowDimension(); r++) {
			for(int c = 0; c < jama_mat_4.getColumnDimension(); c++) {
				jama_mat_4.set(r, c, mat_4.get(r).get(c).doubleValue());
			}
		}
	}//end load_jama_mat_4

	//Test matrix equality between two 2D ArrayList matrices
	public boolean test_mat_equality(ArrayList<ArrayList<Number>> mat_a, ArrayList<ArrayList<Number>> mat_b) {
		//Check dimensions
		if(!(mat_a.size() == mat_b.size()) && (mat_a.get(FIRST).size() == mat_b.get(FIRST).size())) {
			return false;
		}

		//Check contents. Can safely assume same dimensions.
		for(int r = 0; r < mat_a.size(); r++) {
			for(int c = 0; c < mat_a.get(r).size(); c++) {
				//If the values don't match at any point, return false.
				if(!(mat_a.get(r).get(c).equals(mat_b.get(r).get(c)))) {
					return false;
				}
			}//end inner for loop
		}//end outer for loop

		//Safely assume resulting matrices are equal.
		return true;
	}//end test_mat_equality (2D ArrayList, 2D ArrayList) method

	//Test matrix equality between a 2D ArrayList matrix and a Matrix Object
	public boolean test_mat_equality(ArrayList<ArrayList<Number>> arrList_mat, Matrix obj_mat) {
		//Test Dimensions
		if(!(arrList_mat.size() == obj_mat.getRowDimension() && arrList_mat.get(0).size() == obj_mat.getColumnDimension())) {
			return false;
		}

		//Check contents. Safe to assume same dimensions
		for(int r = 0; r < arrList_mat.size(); r++) {
			for(int c = 0; c < arrList_mat.get(0).size(); c++) {
				if(arrList_mat.get(r).get(c).doubleValue() != obj_mat.get(r,c)) {
					return false;
				}
			}//end inner for loop
		}//end outer for loop

		return true;
	}//end test_mat_equality(2D ArrayList, Matrix) method

	//Prompt the user for the first matrix to add
	public String prompt_first_mat(){
		Scanner input = new Scanner(System.in);
		System.out.println("\nPlease enter the first matrix that you wish to use."
				+ "\n(Options: Mat1, Mat2, Mat3, Mat4): ");
		String temp = input.next();
		return temp.strip();
	}//end prompt_first_mat method

	//Prompt the user for the second matrix to add
	public String prompt_second_mat(){
		Scanner input = new Scanner(System.in);
		System.out.println("\nPlease enter the second matrix that you wish to use."
				+ "\n(Options: Mat1, Mat2, Mat3, Mat4): ");
		String temp = input.next();
		return temp.strip();
	}//end prompt_second_mat method

	public String prompt_first_vec(){
		Scanner input = new Scanner(System.in);
		System.out.println("\nPlease enter the first vector that you wish to use."
				+ "\n(Options: r, s, u, v, w): ");
		String temp = input.next();
		return temp.strip();
	}//end prompt_first_vec method

	public String prompt_second_vec(){
		Scanner input = new Scanner(System.in);
		System.out.println("\nPlease enter the second vector that you wish to use."
				+ "\n(Options: r, s, u, v, w): ");
		String temp = input.next();
		return temp.strip();
	}//end prompt_second_mat method

	//If the name matches an existing matrix, return the corresponding matrix.
	public ArrayList<ArrayList<Number>> give_corresponding_matrix(String matched_mat_name) {
		if(matched_mat_name.equalsIgnoreCase("Mat1")) { 
			return mat_1;
		}else if(matched_mat_name.equalsIgnoreCase("Mat2")) {
			return mat_2;
		}else if(matched_mat_name.equalsIgnoreCase("Mat3")) {
			return mat_3;
		}else if(matched_mat_name.equalsIgnoreCase("Mat4")) {
			return mat_4;
		}else {
			//If, for some reason, this is accessed, make a note and return an empty ArrayList<ArrayList<Number>>.
			ArrayList<ArrayList<Number>> empty = new ArrayList<ArrayList<Number>>();
			System.out.println("\nError in the give_corresponding_matrix method: bad name made it through.");
			return empty;
		}//end if/else block
	}//end give_corresponding method

	public Vector give_corresponding_vector(String matched_vec_name) {
		if(matched_vec_name.equalsIgnoreCase("r")) { 
			return vec_r;
		}else if(matched_vec_name.equalsIgnoreCase("s")) {
			return vec_s;
		}else if(matched_vec_name.equalsIgnoreCase("u")) {
			return vec_u;
		}else if(matched_vec_name.equalsIgnoreCase("v")) {
			return vec_v;
		}else if(matched_vec_name.equalsIgnoreCase("w")) {
			return vec_w;
		}else {
			//If, for some reason, this is accessed, make a note and return null
			System.out.println("\nError in the give_corresponding_vector method: bad name made it through.");
			return null;
		}//end if/else block
	}//end give_corresponding_vector method

	//Check if the given name corresponds to an existing matrix or vector.
	public boolean check_existing(String name) {
		if(name.equalsIgnoreCase("Mat1") || name.equalsIgnoreCase("Mat2") 
				|| name.equalsIgnoreCase("Mat3") || name.equalsIgnoreCase("Mat4")) {
			return true;
		}else if(name.equalsIgnoreCase("r") || name.equalsIgnoreCase("s")
				|| name.equalsIgnoreCase("u") || name.equalsIgnoreCase("v")
				|| name.equalsIgnoreCase("w")) {
			return true;
		}
		return false;
	}//end check_existing method

	public File create_output_file(char vec_name_1, char vec_name_2, String part) {
		return new File("abruce_"+ part +"_out" + vec_name_1 + vec_name_2 + ".txt");
	}//end create_output_file method

	public File create_output_file(String input_number, String part, char calculation) {
		return new File("abruce_"+ part +"_out" + calculation + input_number + ".txt");
	}//end create_output_file method
	
	public File create_output_file(String input_name, String part) {
		return new File("abruce_"+ part +"_mat" + input_name + ".txt");
	}//end create_output_file method

	//Create a new File with corresponding name	
	public File create_output_file(String mat_name_1, String mat_name_2, String part_name) {
		String suffix = "";

		//Decide on the first number in the file name's suffix
		if(mat_name_1.equalsIgnoreCase("Mat1")) {
			suffix += "1";
		}else if (mat_name_1.equalsIgnoreCase("Mat2")) {
			suffix += "2";
		}else if (mat_name_1.equalsIgnoreCase("Mat3")) {
			suffix += "3";
		}else if (mat_name_1.equalsIgnoreCase("Mat4")) {
			suffix += "4";
		}else {
			suffix += mat_name_1;
		}

		//Decide on the second number in the file name's suffix
		if(mat_name_2.equalsIgnoreCase("Mat1")) {
			suffix += "1";
		}else if(mat_name_2.equalsIgnoreCase("Mat2")) {
			suffix += "2";
		}else if(mat_name_2.equalsIgnoreCase("Mat3")) {
			suffix += "3";
		}else if(mat_name_2.equalsIgnoreCase("Mat4")) {
			suffix += "4";
		}else {
			suffix += mat_name_2;
		}

		return new File("abruce_"+ part_name +"_out" + suffix + ".txt");
	}//end create_output_file (String, String, String) method

	//Create a new File with corresponding name if a letter is needed
	public File create_output_file(String mat_name_1, String mat_name_2, String part_name, char calculation) {
		String suffix = "";

		//Decide on the letter in the suffix
		suffix += calculation;
		suffix = suffix.toUpperCase();

		//Decide on the first number in the file name's suffix
		if(mat_name_1.equalsIgnoreCase("Mat1")) {
			suffix += "1";
		}else if (mat_name_1.equalsIgnoreCase("Mat2")) {
			suffix += "2";
		}else if (mat_name_1.equalsIgnoreCase("Mat3")) {
			suffix += "3";
		}else if (mat_name_1.equalsIgnoreCase("Mat4")) {
			suffix += "4";
		}else {
			suffix += mat_name_1;
		}

		//Decide on the second number in the file name's suffix
		if(mat_name_2.equalsIgnoreCase("Mat1")) {
			suffix += "1";
		}else if(mat_name_2.equalsIgnoreCase("Mat2")) {
			suffix += "2";
		}else if(mat_name_2.equalsIgnoreCase("Mat3")) {
			suffix += "3";
		}else if(mat_name_2.equalsIgnoreCase("Mat4")) {
			suffix += "4";
		}else {
			suffix += mat_name_2;
		}

		return new File("abruce_"+ part_name + "_out" + suffix + ".txt");
	}//end create_output_file (String, String, String, char) method

	//Print a 2D matrix to a file.
	public void print_file(ArrayList<ArrayList<Number>> matrix, File file) {
		try {
			FileWriter fw = new FileWriter(file);
			fw.write("Andy = 4\nBruce = 5\n\n");

			for(int r = 0; r < matrix.size(); r++) {
				for(int c = 0; c < matrix.get(r).size(); c++) {
					fw.write(matrix.get(r).get(c).toString() + " ");
				}//end inner for loop
				fw.write("\n");
			}//end outer for loop

			fw.close();
			System.out.println("Data written to file \"" + file.getName() + "\"");
		}catch(IOException io) {
			System.out.println("\nIO Exception in print_file method:\nMatrix:");
			print_console(matrix);
		}//end try/catch block

	}//end print_file method

	public void print_file(Matrix matrix, File file) {
		try {
			FileWriter fw = new FileWriter(file);
			fw.write("Andy = 4\nBruce = 5\n\n");

			for(int r = 0; r < matrix.getRowDimension(); r++) {
				for(int c = 0; c < matrix.getColumnDimension(); c++) {
					fw.write(matrix.get(r,c) + " ");
				}//end inner for loop
				fw.write("\n");
			}//end outer for loop

			fw.close();
			System.out.println("Data written to file \"" + file.getName() + "\"");
		}catch(IOException io) {
			System.out.println("\nIO Exception in print_file method:\nMatrix:");
			print_console(matrix);
		}//end try/catch block

	}//end print_file (Matrix) method

	public void print_file(double number, File file) {
		try {
			FileWriter fw = new FileWriter(file);
			String temp_str = "" + number;
			fw.write(temp_str);

			fw.close();
			System.out.println("Data written to file \"" + file.getName() + "\"");
		}catch(IOException io) {
			System.out.println("\nIO Exception in print_file method:\nData:\n\t" + number);
		}//end try/catch block

	}//end print_file (Matrix) method

	//Print a 2D matrix to console for testing.

	public void print_console(ArrayList<ArrayList<Number>> matrix) {
		System.out.println("\nAndy = 4\nBruce = 5");

		for(int r = 0; r < matrix.size(); r++) {
			for(int c = 0; c < matrix.get(r).size(); c++) {
				System.out.print(matrix.get(r).get(c) + " ");
			}//end inner for loop
			System.out.println();
		}//end outer for loop
	}//end print_console method


	public void print_console(Matrix matrix) {
		System.out.println("\nAndy = 4\nBruce = 5");

		for(int r = 0; r < matrix.getRowDimension(); r++) {
			for(int c = 0; c < matrix.getColumnDimension(); c++) {
				System.out.print(matrix.get(r,c) + " ");
			}//end inner for loop
			System.out.println();
		}//end outer for loop
	}//end print_console (Matrix) method

}//end Abruce_p1 class
