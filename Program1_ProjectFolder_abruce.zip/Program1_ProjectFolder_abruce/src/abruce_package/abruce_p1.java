package abruce_package;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class abruce_p1 {
	private ArrayList<ArrayList<Number>> mat_1;
	private ArrayList<ArrayList<Number>> mat_2;
	private ArrayList<ArrayList<Number>> mat_3;
	private ArrayList<ArrayList<Number>> mat_4;

	private final int FIRST = 4;//Andy
	private final int LAST = 5;//Bruce

	File file_1;
	File file_2;
	File file_3;
	File file_4;
	
	public abruce_p1() {
		mat_1 = new ArrayList<ArrayList<Number>>();
		mat_2 = new ArrayList<ArrayList<Number>>();
		mat_3 = new ArrayList<ArrayList<Number>>();
		mat_4 = new ArrayList<ArrayList<Number>>();
	
		file_1 = new File("abruce_mat1.txt");
		file_2 = new File("abruce_mat2.txt");
		file_3 = new File("abruce_mat3.txt");
		file_4 = new File("abruce_mat4.txt");
	}//end constructor

	public void logic() {
		fill_mat1();
		fill_mat2();
		fill_mat3();
		fill_mat4();

		print_file(mat_1, file_1);
		print_file(mat_2, file_2);
		print_file(mat_3, file_3);
		print_file(mat_4, file_4);
	}//end p1_logic method

	//Mat1 method
	public void fill_mat1() {
		int value = 1;
		//Num rows = LAST. Num cols = FIRST
		for(int r = 0; r < LAST; r++) {
			//Create and load an ArrayList
			ArrayList<Number> temp = new ArrayList<Number>();

			for(int c = 0; c < FIRST; c++) {
				temp.add((Number)value);
				value++;
			}//end inner for loop

			mat_1.add(temp);
		}//end outer for loop
	}//end fill_mat1 method

	//Mat2 method
	public void fill_mat2() {
		//Create the empty 2D ArrayList
		for(int r = 0; r < LAST; r++) {
			ArrayList<Number> temp = new ArrayList<Number>();
			for(int c = 0; c < FIRST; c++) {
				temp.add((Number)0);
			}
			mat_2.add(temp);
		}//end initializing 2d ArrayList

		//Fill the matrix
		int value = 2;
		//Num rows = LAST. Num cols = FIRST 
		for(int c = 0; c < FIRST; c++) {
			for(int r = 0; r < LAST; r++) {
				mat_2.get(r).set(c,(Number)value);
				value += 3;
			}//end inner loop
		}//end outer loop
	}//end fill_mat2 method

	//Mat3 method
	public void fill_mat3() {
		int value = 10;

		//Num rows = 2. Num cols = 4
		for(int r = 0; r < 2; r++) {
			ArrayList<Number> temp = new ArrayList<Number>();

			for(int c = 0; c < 4; c++) {
				temp.add((Number)value);
				value -= 2;
			}//end inner loop

			mat_3.add(temp);
		}//end outer loop
	}//end fill_mat3 method

	//Mat4 method
	public void fill_mat4() {
		//Create the empty 2D ArrayList
		//Num rows = 4. Num cols = 2.
		for(int r = 0; r < 4; r++) {
			ArrayList<Number> temp = new ArrayList<Number>();
			for(int c = 0; c < 2; c++) {
				temp.add((Number)0);
			}
			mat_4.add(temp);
		}//end initializing 2d ArrayList
		
		//Fill the matrix
		double value = -6.0;
		//Num rows = 4. Num cols = 2.
		for(int c = 0; c < 2; c++) {
			for(int r = 0; r < 4; r++) {
				mat_4.get(r).set(c, (Number)value);
				value += 1.5;
			}//end inner for loop
		}//end outer for loop
	}//end fill_mat4 method

	
	
	
	//Print to file
	public void print_file(ArrayList<ArrayList<Number>> matrix, File file) {
		try {
			FileWriter fw = new FileWriter(file);
			fw.write("Andy = 4\nBruce = 5\n\n");

			for(int r = 0; r < matrix.size(); r++) {
				for(int c = 0; c < matrix.get(r).size(); c++) {
					fw.write(matrix.get(r).get(c).toString() + " ");
				}//end inner for loop
				fw.write("\n");
			}//end outer for loop

			fw.close();
			System.out.println("Data written to file \"" + file.getName() + "\"");
		}catch(IOException io) {
			System.out.println("\nIO Exception in print_file method:\nMatrix:");
			print_console(matrix);
		}//end try/catch block

	}//end print_file method

	//Print to console (good for testing)
	public void print_console(ArrayList<ArrayList<Number>> matrix) {
		System.out.println("\nAndy = 4\nBruce = 5");

		for(int r = 0; r < matrix.size(); r++) {
			for(int c = 0; c < matrix.get(r).size(); c++) {
				System.out.print(matrix.get(r).get(c) + " ");
			}//end inner for loop
			System.out.println();
		}//end outer for loop
	}//end print_console method

	public File share_file(String name) {
		if(name.equalsIgnoreCase("abruce_mat1.txt")) {
			return file_1;
		}else if(name.equalsIgnoreCase("abruce_mat2.txt")) {
			return file_2;
		}else if(name.equalsIgnoreCase("abruce_mat3.txt")) {
			return file_3;
		}else if(name.equalsIgnoreCase("abruce_mat4.txt")) {
			return file_4;
		}else {
			return null;
		}
	}//end share_file method
	
}//end abruce_p1 class
