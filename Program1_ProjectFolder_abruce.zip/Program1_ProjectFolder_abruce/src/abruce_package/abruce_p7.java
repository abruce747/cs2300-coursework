package abruce_package;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import Jama.Matrix;

public class abruce_p7 {

	private Vector vec_r;
	private Vector vec_s;
	private Vector vec_u;
	private Vector vec_v;
	private Vector vec_w;

	private ArrayList<ArrayList<Number>> mat_1;
	private ArrayList<ArrayList<Number>> mat_2;
	private ArrayList<ArrayList<Number>> mat_3;
	private ArrayList<ArrayList<Number>> mat_4;

	//Instance variables using my chosen library from https://math.nist.gov/javanumerics/jama/doc/Jama/package-summary.html
	private Matrix jama_mat_1;
	private Matrix jama_mat_2;
	private Matrix jama_mat_3;
	private Matrix jama_mat_4;

	public abruce_p7(File f1, File f2, File f3, File f4) {
		//Prepare the Vectors for the dot production part
		vec_r = new Vector(-1, -2);
		vec_s = new Vector(-3, 3);
		vec_u = new Vector(2, -1);
		vec_v = new Vector(3, 1);
		vec_w = new Vector(1, 3);

		//Prepare the Matrices for the transposition part
		//Data from the files goes into 2D ArrayList goes into the Matrix objects

		//(No, this is not as simple or concise as it should be, but I wrote all my 
		//	code in one class, so the quickest way to fix it was to use what I already
		//	made and avoid writing new code unless absolutely necessary.

		//Load the matrices
		mat_1 = read_file(f1);
		mat_2 = read_file(f2);
		mat_3 = read_file(f3);
		mat_4 = read_file(f4);

		load_jama_mat_1();
		load_jama_mat_2();
		load_jama_mat_3();
		load_jama_mat_4();
	}//end constructor

	public void logic() {
		//1.) Dot product (vectors represented by 2 by 1 matrix)
		jama_dot_product_logic();
		//2.) Transpose the four original Matrix objects
		jama_transpose_logic();
	}//end logic method


	public void jama_dot_product_logic() {
		//Prompt, check, calculate, and write vectors as long as the user wants.
		boolean loop_again = true;
		do {
			//Ask if the user would like to test any vectors
			System.out.println("\nWould you like to calculate a dot product using the JAMA library?"
					+ "\nEnter Y for yes or N for no: ");
			Scanner input = new Scanner(System.in);
			String response = input.nextLine().strip();
			if(response.equalsIgnoreCase("n") || response.equalsIgnoreCase("no")) {
				loop_again = false;
				continue;	//exits the loop
			}else if(response.equalsIgnoreCase("y") || response.equalsIgnoreCase("yes")){
				loop_again = true;
			}else {
				continue;
			}

			//Prompt for vectors
			System.out.println("\nThe following prompts refer to vector dot products using JAMA:");
			String first_vec_name = prompt_first_vec();
			String second_vec_name = prompt_second_vec();

			//If user choice is invalid, then continue to next iteration and ask again.
			if(!(check_existing(first_vec_name) && check_existing(second_vec_name))) {
				System.out.println("\nInvalid name choice(s). Try again.");
				continue;
			}

			//Create temporary Vectors
			Vector vec_a = give_corresponding_vector(first_vec_name); // 2 by 1, need a 1 by 2
			Vector vec_b = give_corresponding_vector(second_vec_name); // 2 by 1

			//Convert the vectors to Jama matrix objects
			//Need to rotate the first vector matrix to enable multiplication
			double[][] vec_a_rotated = new double[1][2];
			vec_a_rotated[0][0] = vec_a.get_component_1();
			vec_a_rotated[0][1] = vec_a.get_component_2();

			Matrix vec_a_mat = new Matrix(vec_a_rotated);//now 1x2
			Matrix vec_b_mat = new Matrix(vec_b.get_vec());//2x1

			//Product of 1 by 2 and 2 by 1 gives 1 by 1 (scalar)
			Matrix product = vec_a_mat.times(vec_b_mat);

			//Write the new matrix to the corresponding file
			print_file(product, create_output_file(first_vec_name, second_vec_name, "p7", 'D'));

		}while(loop_again);
		System.out.println("\nPart 7's dot product loop has been exited.");
	}//end jama_dot_product_flow method

	public void jama_transpose_logic() {
		//No user input. Transpose all four original matrices
		Matrix jama_mat_1_t = jama_mat_1.transpose();
		Matrix jama_mat_2_t = jama_mat_2.transpose();
		Matrix jama_mat_3_t = jama_mat_3.transpose();
		Matrix jama_mat_4_t = jama_mat_4.transpose();

		//Print to files
		print_file(jama_mat_1_t, create_output_file("T","1","p7"));
		print_file(jama_mat_2_t, create_output_file("T","2","p7"));
		print_file(jama_mat_3_t, create_output_file("T","3","p7"));
		print_file(jama_mat_4_t, create_output_file("T","4","p7"));
	}//end jama_transpose_flow method

	//Create a new File with corresponding name	
	public File create_output_file(String operation, String matrix_name, String part_name) {
		String suffix = "" + operation;
		suffix = suffix.toUpperCase();
		
		//Decide on the number in the file name's suffix
		if(matrix_name.equalsIgnoreCase("Mat1")) {
			suffix += "1";
		}else if (matrix_name.equalsIgnoreCase("Mat2")) {
			suffix += "2";
		}else if (matrix_name.equalsIgnoreCase("Mat3")) {
			suffix += "3";
		}else if (matrix_name.equalsIgnoreCase("Mat4")) {
			suffix += "4";
		}else {
			suffix += matrix_name;
		}

		return new File("abruce_"+ part_name +"_out" + suffix + ".txt");
	}//end create_output_file (String, String, String) method

	//Convert file data into 2D ArrayList
	public ArrayList<ArrayList<Number>> read_file(File file){
		try {
			ArrayList<ArrayList<Number>> temp_mat = new ArrayList<ArrayList<Number>>();
			Scanner reader = new Scanner(file);

			while(reader.hasNextLine()) {
				String line = reader.nextLine();

				if(line.contains("Andy = 4") || line.contains("Bruce = 5") || line.equalsIgnoreCase("")) {
					//Handles if the line is the header
					continue;
				}else {
					//Create a row for the matrix from the line
					ArrayList<Number> temp_row = new ArrayList<Number>();

					while(line.length() > 0) {
						//Isolate the first number, if the line has a space
						String sub_str = "";
						if(line.contains(" ")) {
							int space_index = line.indexOf(' ');
							sub_str = line.substring(0, space_index);
						}else {
							//Likely dealing with the last number in a line
							sub_str = line;
						}

						//Account for doubles and ints
						if(sub_str.contains(".")) {
							temp_row.add((Number)Double.parseDouble(sub_str));
						}else {
							temp_row.add((Number)Integer.parseInt(sub_str));
						}	

						//Remove the number from the line
						line = line.replaceFirst(sub_str, "");
						line = line.strip();
					}//end inner while loop

					//Add the row
					temp_mat.add(temp_row);
				}//end if/else block
			}//end outer while loop

			return temp_mat;
		}catch(FileNotFoundException fnf) {
			System.out.println("\nFile missing in read file step: "+ file.getName());
			return null;
		}//end try/catch block
	}//end read_file

	//4 methods to load each Matrix object from the 2D ArrayList
	public void load_jama_mat_1() {		
		//Initialize an empty Matrix object with mat_1's dimensions
		jama_mat_1 = new Matrix(mat_1.size(), mat_1.get(0).size());

		//Copy data into the Matrix
		for(int r = 0; r < jama_mat_1.getRowDimension(); r++) {
			for(int c = 0; c < jama_mat_1.getColumnDimension(); c++) {
				jama_mat_1.set(r, c, mat_1.get(r).get(c).doubleValue());
			}
		}

	}//end load_jama_mat_1

	public void load_jama_mat_2() {		
		//Initialize an empty Matrix object with mat_2's dimensions
		jama_mat_2 = new Matrix(mat_2.size(), mat_2.get(0).size());

		//Copy data into the Matrix
		for(int r = 0; r < jama_mat_2.getRowDimension(); r++) {
			for(int c = 0; c < jama_mat_2.getColumnDimension(); c++) {
				jama_mat_2.set(r, c, mat_2.get(r).get(c).doubleValue());
			}
		}
	}//end load_jama_mat_2

	public void load_jama_mat_3() {		
		//Initialize an empty Matrix object with mat_3's dimensions
		jama_mat_3 = new Matrix(mat_3.size(), mat_3.get(0).size());

		//Copy data into the Matrix
		for(int r = 0; r < jama_mat_3.getRowDimension(); r++) {
			for(int c = 0; c < jama_mat_3.getColumnDimension(); c++) {
				jama_mat_3.set(r, c, mat_3.get(r).get(c).doubleValue());
			}
		}	
	}//end load_jama_mat_3

	public void load_jama_mat_4() {		
		//Initialize an empty Matrix object with mat_4's dimensions
		jama_mat_4 = new Matrix(mat_4.size(), mat_4.get(0).size());

		//Copy data into the Matrix
		for(int r = 0; r < jama_mat_4.getRowDimension(); r++) {
			for(int c = 0; c < jama_mat_4.getColumnDimension(); c++) {
				jama_mat_4.set(r, c, mat_4.get(r).get(c).doubleValue());
			}
		}
	}//end load_jama_mat_4

	public void print_file(Matrix matrix, File file) {
		try {
			FileWriter fw = new FileWriter(file);
			fw.write("Andy = 4\nBruce = 5\n\n");

			for(int r = 0; r < matrix.getRowDimension(); r++) {
				for(int c = 0; c < matrix.getColumnDimension(); c++) {
					fw.write(matrix.get(r,c) + " ");
				}//end inner for loop
				fw.write("\n");
			}//end outer for loop

			fw.close();
			System.out.println("Data written to file \"" + file.getName() + "\"");
		}catch(IOException io) {
			System.out.println("\nIO Exception in print_file method:\nMatrix:");
			print_console(matrix);
		}//end try/catch block

	}//end print_file (Matrix) method

	public void print_console(Matrix matrix) {
		System.out.println("\nAndy = 4\nBruce = 5");

		for(int r = 0; r < matrix.getRowDimension(); r++) {
			for(int c = 0; c < matrix.getColumnDimension(); c++) {
				System.out.print(matrix.get(r,c) + " ");
			}//end inner for loop
			System.out.println();
		}//end outer for loop
	}//end print_console (Matrix) method

	//Create a new File with corresponding name if a letter is needed
	public File create_output_file(String factor_name_1, String factor_name_2, String part_name, char calculation) {
		String suffix = "";

		//Decide on the letter in the suffix
		suffix += calculation;
		suffix = suffix.toUpperCase();

		//Decide on the first number in the file name's suffix
		if(factor_name_1.equalsIgnoreCase("Mat1")) {
			suffix += "1";
		}else if (factor_name_1.equalsIgnoreCase("Mat2")) {
			suffix += "2";
		}else if (factor_name_1.equalsIgnoreCase("Mat3")) {
			suffix += "3";
		}else if (factor_name_1.equalsIgnoreCase("Mat4")) {
			suffix += "4";
		}else {
			suffix += factor_name_1;
		}

		//Decide on the second number in the file name's suffix
		if(factor_name_2.equalsIgnoreCase("Mat1")) {
			suffix += "1";
		}else if(factor_name_2.equalsIgnoreCase("Mat2")) {
			suffix += "2";
		}else if(factor_name_2.equalsIgnoreCase("Mat3")) {
			suffix += "3";
		}else if(factor_name_2.equalsIgnoreCase("Mat4")) {
			suffix += "4";
		}else {
			suffix += factor_name_2;
		}

		return new File("abruce_"+ part_name + "_out" + suffix + ".txt");
	}//end create_output_file (String, String, String, char) method

	public Vector give_corresponding_vector(String matched_vec_name) {
		if(matched_vec_name.equalsIgnoreCase("r")) { 
			return vec_r;
		}else if(matched_vec_name.equalsIgnoreCase("s")) {
			return vec_s;
		}else if(matched_vec_name.equalsIgnoreCase("u")) {
			return vec_u;
		}else if(matched_vec_name.equalsIgnoreCase("v")) {
			return vec_v;
		}else if(matched_vec_name.equalsIgnoreCase("w")) {
			return vec_w;
		}else {
			//If, for some reason, this is accessed, make a note and return null
			System.out.println("\nError in the give_corresponding_vector method: bad name made it through.");
			return null;
		}//end if/else block
	}//end give_corresponding_vector method

	//Check if the given name corresponds to an existing matrix or vector.
	public boolean check_existing(String name) {
		if(name.equalsIgnoreCase("Mat1") || name.equalsIgnoreCase("Mat2") 
				|| name.equalsIgnoreCase("Mat3") || name.equalsIgnoreCase("Mat4")) {
			return true;
		}else if(name.equalsIgnoreCase("r") || name.equalsIgnoreCase("s")
				|| name.equalsIgnoreCase("u") || name.equalsIgnoreCase("v")
				|| name.equalsIgnoreCase("w")) {
			return true;
		}
		return false;
	}//end check_existing method

	public String prompt_first_vec(){
		Scanner input = new Scanner(System.in);
		System.out.println("\nPlease enter the first vector that you wish to use."
				+ "\n(Options: r, s, u, v, w): ");
		String temp = input.next();
		return temp.strip();
	}//end prompt_first_vec method

	public String prompt_second_vec(){
		Scanner input = new Scanner(System.in);
		System.out.println("\nPlease enter the second vector that you wish to use."
				+ "\n(Options: r, s, u, v, w): ");
		String temp = input.next();
		return temp.strip();
	}//end prompt_second_mat method


}//end abruce_p7 class
