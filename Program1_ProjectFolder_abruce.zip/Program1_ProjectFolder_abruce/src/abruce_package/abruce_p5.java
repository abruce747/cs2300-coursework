package abruce_package;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class abruce_p5 {

	private Vector vec_r;
	private Vector vec_s;
	private Vector vec_u;
	private Vector vec_v;
	private Vector vec_w;


	public abruce_p5() {
		vec_r = new Vector(-1, -2);
		vec_s = new Vector(-3, 3);
		vec_u = new Vector(2, -1);
		vec_v = new Vector(3, 1);
		vec_w = new Vector(1, 3);
	}//end constructor

	public void logic() {
		//Prompt, check, calculate, and write vectors as long as the user wants.
		boolean loop_again = true;

		do {
			//Ask if the user would like to test any vectors
			System.out.println("\nWould you like to calculate a dot product?"
					+ "\nEnter Y for yes or N for no: ");
			Scanner input = new Scanner(System.in);
			String response = input.nextLine().strip();
			if(response.equalsIgnoreCase("n") || response.equalsIgnoreCase("no")) {
				loop_again = false;
				continue;	//exits the loop
			}else if(response.equalsIgnoreCase("y") || response.equalsIgnoreCase("yes")){
				loop_again = true;
			}else {
				continue;
			}

			//Prompt for vectors
			System.out.println("\nThe following prompts refer to vector dot products:");
			String first_vec_name = prompt_first_vec();
			String second_vec_name = prompt_second_vec();

			//If user choice is invalid, then continue to next iteration and ask again.
			if(!(check_existing(first_vec_name) && check_existing(second_vec_name))) {
				System.out.println("\nInvalid name choice(s). Try again.");
				continue;
			}

			//Create temporary Vectors
			Vector vec_a = give_corresponding_vector(first_vec_name);
			Vector vec_b = give_corresponding_vector(second_vec_name);

			double product = vec_a.dot_product(vec_b);

			//Write the new matrix to the corresponding file
			print_file(product, create_output_file(first_vec_name, second_vec_name, "p5"));

		}while(loop_again);
		System.out.println("\nPart 5's dot product loop has been exited.");
	}//end logic method

	//Check if the given name corresponds to an existing matrix or vector.
	public boolean check_existing(String name) {
		if(name.equalsIgnoreCase("r") || name.equalsIgnoreCase("s")
				|| name.equalsIgnoreCase("u") || name.equalsIgnoreCase("v")
				|| name.equalsIgnoreCase("w")) {
			return true;
		}
		return false;
	}//end check_existing method

	//Create a new File with corresponding name	
	public File create_output_file(String vec_1_letter, String vec_2_letter, String part_name) {
		String suffix = vec_1_letter + vec_2_letter;

		return new File("abruce_"+ part_name +"_out" + suffix + ".txt");
	}//end create_output_file (String, String, String) method

	public Vector give_corresponding_vector(String matched_vec_name) {
		if(matched_vec_name.equalsIgnoreCase("r")) { 
			return vec_r;
		}else if(matched_vec_name.equalsIgnoreCase("s")) {
			return vec_s;
		}else if(matched_vec_name.equalsIgnoreCase("u")) {
			return vec_u;
		}else if(matched_vec_name.equalsIgnoreCase("v")) {
			return vec_v;
		}else if(matched_vec_name.equalsIgnoreCase("w")) {
			return vec_w;
		}else {
			//If, for some reason, this is accessed, make a note and return null
			System.out.println("\nError in the give_corresponding_vector method: bad name made it through.");
			return null;
		}//end if/else block
	}//end give_corresponding_vector method

	public String prompt_first_vec(){
		Scanner input = new Scanner(System.in);
		System.out.println("\nPlease enter the first vector that you wish to use."
				+ "\n(Options: r, s, u, v, w): ");
		String temp = input.next();
		return temp.strip();
	}//end prompt_first_vec method

	public String prompt_second_vec(){
		Scanner input = new Scanner(System.in);
		System.out.println("\nPlease enter the second vector that you wish to use."
				+ "\n(Options: r, s, u, v, w): ");
		String temp = input.next();
		return temp.strip();
	}//end prompt_second_mat method

	public void print_file(double number, File file) {
		try {
			FileWriter fw = new FileWriter(file);
			String temp_str = "" + number;
			fw.write(temp_str);

			fw.close();
			System.out.println("Data written to file \"" + file.getName() + "\"");
		}catch(IOException io) {
			System.out.println("\nIO Exception in print_file method:\nData:\n\t" + number);
		}//end try/catch block

	}//end print_file (Matrix) method


}//end abruce_p5 class
